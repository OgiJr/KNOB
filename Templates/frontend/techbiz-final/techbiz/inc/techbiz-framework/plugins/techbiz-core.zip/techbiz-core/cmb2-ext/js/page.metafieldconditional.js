(function($){
    "use strict";
    
    let $techbiz_page_breadcrumb_area      = $("#_techbiz_page_breadcrumb_area");
    let $techbiz_page_settings             = $("#_techbiz_page_breadcrumb_settings");
    let $techbiz_page_breadcrumb_image     = $("#_techbiz_breadcumb_image");
    let $techbiz_page_title                = $("#_techbiz_page_title");
    let $techbiz_page_title_settings       = $("#_techbiz_page_title_settings");

    if( $techbiz_page_breadcrumb_area.val() == '1' ) {
        $(".cmb2-id--techbiz-page-breadcrumb-settings").show();
        if( $techbiz_page_settings.val() == 'global' ) {
            $(".cmb2-id--techbiz-breadcumb-image").hide();
            $(".cmb2-id--techbiz-page-title").hide();
            $(".cmb2-id--techbiz-page-title-settings").hide();
            $(".cmb2-id--techbiz-custom-page-title").hide();
            $(".cmb2-id--techbiz-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--techbiz-breadcumb-image").show();
            $(".cmb2-id--techbiz-page-title").show();
            $(".cmb2-id--techbiz-page-breadcrumb-trigger").show();
    
            if( $techbiz_page_title.val() == '1' ) {
                $(".cmb2-id--techbiz-page-title-settings").show();
                if( $techbiz_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--techbiz-custom-page-title").hide();
                } else {
                    $(".cmb2-id--techbiz-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--techbiz-page-title-settings").hide();
                $(".cmb2-id--techbiz-custom-page-title").hide();
    
            }
        }
    } else {
        $techbiz_page_breadcrumb_area.parents('.cmb2-id--techbiz-page-breadcrumb-area').siblings().hide();
    }


    // breadcrumb area
    $techbiz_page_breadcrumb_area.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--techbiz-page-breadcrumb-settings").show();
            if( $techbiz_page_settings.val() == 'global' ) {
                $(".cmb2-id--techbiz-breadcumb-image").hide();
                $(".cmb2-id--techbiz-page-title").hide();
                $(".cmb2-id--techbiz-page-title-settings").hide();
                $(".cmb2-id--techbiz-custom-page-title").hide();
                $(".cmb2-id--techbiz-page-breadcrumb-trigger").hide();
            } else {
                $(".cmb2-id--techbiz-breadcumb-image").show();
                $(".cmb2-id--techbiz-page-title").show();
                $(".cmb2-id--techbiz-page-breadcrumb-trigger").show();
        
                if( $techbiz_page_title.val() == '1' ) {
                    $(".cmb2-id--techbiz-page-title-settings").show();
                    if( $techbiz_page_title_settings.val() == 'default' ) {
                        $(".cmb2-id--techbiz-custom-page-title").hide();
                    } else {
                        $(".cmb2-id--techbiz-custom-page-title").show();
                    }
                } else {
                    $(".cmb2-id--techbiz-page-title-settings").hide();
                    $(".cmb2-id--techbiz-custom-page-title").hide();
        
                }
            }
        } else {
            $(this).parents('.cmb2-id--techbiz-page-breadcrumb-area').siblings().hide();
        }
    });

    // page title
    $techbiz_page_title.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--techbiz-page-title-settings").show();
            if( $techbiz_page_title_settings.val() == 'default' ) {
                $(".cmb2-id--techbiz-custom-page-title").hide();
            } else {
                $(".cmb2-id--techbiz-custom-page-title").show();
            }
        } else {
            $(".cmb2-id--techbiz-page-title-settings").hide();
            $(".cmb2-id--techbiz-custom-page-title").hide();

        }
    });

    //page settings
    $techbiz_page_settings.on("change",function(){
        if( $(this).val() == 'global' ) {
            $(".cmb2-id--techbiz-breadcumb-image").hide();
            $(".cmb2-id--techbiz-page-title").hide();
            $(".cmb2-id--techbiz-page-title-settings").hide();
            $(".cmb2-id--techbiz-custom-page-title").hide();
            $(".cmb2-id--techbiz-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--techbiz-breadcumb-image").show();
            $(".cmb2-id--techbiz-page-title").show();
            $(".cmb2-id--techbiz-page-breadcrumb-trigger").show();
    
            if( $techbiz_page_title.val() == '1' ) {
                $(".cmb2-id--techbiz-page-title-settings").show();
                if( $techbiz_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--techbiz-custom-page-title").hide();
                } else {
                    $(".cmb2-id--techbiz-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--techbiz-page-title-settings").hide();
                $(".cmb2-id--techbiz-custom-page-title").hide();
    
            }
        }
    });

    // page title settings
    $techbiz_page_title_settings.on("change",function(){
        if( $(this).val() == 'default' ) {
            $(".cmb2-id--techbiz-custom-page-title").hide();
        } else {
            $(".cmb2-id--techbiz-custom-page-title").show();
        }
    });
    
})(jQuery);